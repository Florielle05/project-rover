#include "liste.h"
#include <stdio.h>

t_list create_list() {
    t_list liste;
    liste.head = NULL;
    return liste;
}

void afficher_liste(t_list liste) {
    t_maillon * curr = NULL;
    curr = liste.head;
    while(curr != NULL) {
        printf("%s  ", getMoveAsString(curr->move) );
        curr = curr->next;
    }
    printf("\n");
}

t_maillon * create_maillon(t_move move){
    t_maillon * maillon;
    maillon = NULL;
    maillon = malloc(1*sizeof(t_maillon));
    if (maillon == NULL) {
        perror("Échec de l'allocation mémoire");
        exit(EXIT_FAILURE);
    }
    maillon->next = NULL;
    maillon->move = move;
    return maillon;
}

void insert_head_maillon(t_list * liste, t_move move){
    t_maillon * new_maillon = create_maillon(move);
    if (liste->head == NULL) {
        liste->head = new_maillon;
        return;
    }
    t_maillon * temp;
    temp = liste->head;
    liste->head = new_maillon;
    new_maillon->next = temp;
}


void delete_move(t_move move, t_list *liste) {
    if (liste == NULL || liste->head == NULL) {
        printf("Liste inexistante ou vide.\n");
        return;
    }

    t_maillon *curr = liste->head;
    t_maillon *prec = NULL;

    // Cas particulier : suppression en tête
    if (curr->move == move) {
        liste->head = curr->next;
        //printf("supression du noeuds  \n");
        //free(curr);
        return;
    }

    // Parcourir la liste pour trouver l'élément
    while (curr != NULL && curr->move != move) {
        prec = curr;
        curr = curr->next;
    }

    // Si l'élément a été trouvé
    if (curr != NULL) {
        prec->next = curr->next;
        //printf("supression du noeuds  \n");
        //free(curr);
    } else {
        printf("Élément non trouvé.\n");
    }
}

t_move send_first_move(t_list * liste) {
    if (liste->head == NULL) {
        printf("liste vide\n");
        return -1; // Remplacez U_TURN + U_TURN par une valeur appropriée
    }
    t_move temp = liste->head->move;
    //delete_move(temp, liste);
    return temp;
}

void liberer_liste(t_list *liste) {
    if (liste == NULL) {
        printf("Liste inexistante ou déjà libérée.\n");
        return;
    }

    t_maillon *current = liste->head;
    t_maillon *next;

    // Parcourir et libérer chaque maillon
    while (current != NULL) {
        next = current->next; // Sauvegarder l'adresse du maillon suivant
        free(current);        // Libérer le maillon actuel
        current = next;       // Passer au suivant
    }

    // Réinitialiser la liste
    liste->head = NULL;
}

void add_move(t_list *list, t_move move) {
    t_maillon *new_maillon = malloc(sizeof(t_maillon));
    if (new_maillon == NULL) {
        perror("Erreur d'allocation mémoire");
        exit(EXIT_FAILURE);
    }
    new_maillon->move = move;
    new_maillon->next = NULL;

    if (list->head == NULL) {
        list->head = new_maillon;
    } else {
        t_maillon *current = list->head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = new_maillon;
    }
}