#ifndef LISTE_H
#define LISTE_H
#include "moves.h"
#include <stdlib.h>

struct n_maillon {
    t_move move;
    struct n_maillon * next;
};
typedef struct n_maillon t_maillon;

struct n_list {
    t_maillon * head;
};
typedef struct n_list t_list;

t_list create_list();
void afficher_liste(t_list liste);
t_maillon * create_maillon(t_move);
void insert_head_maillon(t_list * liste, t_move move);
void delete_move(t_move move, t_list * list);
t_move send_first_move(t_list *);
t_list copie_liste(t_list * );
void liberer_liste(t_list *liste);
void add_move(t_list *list, t_move move) ;


#endif //LISTE_H
