#include "test1.h"
#include "moves.h"
#include "loc.h"
#include "liste.h"
#include "tree1.h"

void test1(){

    t_localisation point;
    point = loc_init(1,0,EAST);
    printf("Test sur le point x=%d y=%d ori=%d\n", point.pos.x, point.pos.y, point.ori);
    point = move(point,U_TURN);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(U_TURN));
    point = move(point,U_TURN);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(U_TURN));
    point = move(point,U_TURN);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(U_TURN));
    point = move(point,T_RIGHT);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(T_RIGHT));
    point = move(point,F_10);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(F_10));
    point = move(point,F_10);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(F_10));
    point = move(point,F_20);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(F_20));
    point = move(point,B_10);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(B_10));
    point = move(point,F_30);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(F_30));
    point = move(point,T_LEFT);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(T_LEFT));
    point = move(point,T_RIGHT);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(T_RIGHT));
    point = move(point,U_TURN);
    printf("x=%d y=%d ori=%d %s\n", point.pos.x, point.pos.y, point.ori, getMoveAsString(U_TURN));
}

void test2(t_map map) {
    int N = 9;
    int A = 4;
    printf("\nProfondeur = %d \n", N-A);
    cheminer_vers_la_base(map, 2,0,SOUTH, N,A );
}


void test3() {

}
