#ifndef TEST_H
#define TEST_H

#include <stdio.h>
#include "map.h"

void test1();
void test2(t_map map);
void test3();

#endif //TEST_H
