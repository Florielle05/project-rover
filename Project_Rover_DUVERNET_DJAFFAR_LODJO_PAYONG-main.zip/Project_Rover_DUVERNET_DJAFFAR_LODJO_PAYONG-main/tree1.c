#include <stdlib.h>
#include <stdio.h>
#include "tree1.h"
#include "queue.h"
#include "map.h"
#include "liste.h"
#include "loc.h"
#include "stack.h"
#include <time.h>

t_n_tree initTree() {
    t_n_tree tree;
    tree.root = NULL;
    return tree;
}

t_n_node * createNode(t_localisation loca, int nbr_sons, t_map map, t_move mouve) {
    t_n_node * new_node = NULL;
    new_node = malloc(sizeof(t_n_node));
    if (new_node == NULL) {
        perror("Échec de l'allocation mémoire");
        exit(EXIT_FAILURE);
    }
    new_node->loc = move(loca, mouve);
    new_node->nbre_sons = nbr_sons;
    if( isValidLocalisation(new_node->loc.pos, map.x_max, map.y_max) ) {
        new_node->cost = map.costs[new_node->loc.pos.y][new_node->loc.pos.x];
    }
    else {
        new_node->cost = 10000;
    }
    new_node->tab_sons = malloc(nbr_sons * sizeof(t_n_node *));
    if (new_node->tab_sons == NULL) {
        printf("Erreur d'allocation mémoire pour les fils.\n");
        exit(EXIT_FAILURE);
    }
    for(int i = 0; i < nbr_sons; i++) {
        new_node->tab_sons[i] = NULL;
    }
    new_node->mouv = mouve;
    return new_node;
}

void makeNode(t_n_node * node, t_list liste, t_map map, int N, int A) {
    t_move temp;
    for(int i = 0; i < node->nbre_sons; i++) {
        temp = send_first_move(&liste);
        delete_move(temp, &liste);
        node->tab_sons[i] = createNode(node->loc, node->nbre_sons - 1, map, temp);
    }
}

void recusive_function(t_maillon liste, t_n_node *node, t_map map, int N, int A) {
    if (node == NULL || node->nbre_sons <= 0) {
        return;
    }

    if(node->nbre_sons == A){
        return;
    }

    t_list temp;
    temp = create_list();
    t_maillon * current = &liste;
    while (current != NULL) {
        add_move(&temp, current->move);
        current = current->next;
    }

    delete_move(node->mouv, &temp);

    makeNode(node, temp, map, N, A);

    for (int i = 0; i < node->nbre_sons; i++) {
        if (node->tab_sons[i] != NULL) {
            recusive_function(*(temp.head), node->tab_sons[i], map, N, A);
        }
    }

    liberer_liste(&temp);
}

void makeTree(t_list liste, t_n_tree *tree, t_map map, t_localisation depart_point, int N, int A) {
    clock_t start_build = clock();

    if (N <= 0 || A <= 0) {
        printf("Erreur : Les paramètres N (%d) et A (%d) doivent être positifs.\n", N, A);
        exit(EXIT_FAILURE);
    }

    t_list liste_move = liste;
    t_localisation point = loc_init(depart_point.pos.x, depart_point.pos.y, depart_point.ori);

    // Créer la racine
    tree->root = createNode(point, N, map, U_TURN);
    tree->root->loc = move(tree->root->loc, U_TURN);

    // Créer les nœuds enfants de la racine
    makeNode(tree->root, liste_move, map, N, A);

    for (int i = 0; i < tree->root->nbre_sons; i++) {
        recusive_function(*liste.head, tree->root->tab_sons[i], map, N, A);
    }

    // Corriger et nettoyer l'arbre
    if (isValidLocalisation(depart_point.pos, map.x_max, map.y_max) && 
        map.soils[depart_point.pos.x][depart_point.pos.y] == 2)
       {
        printf("sol erg\n");
        correct_erg_cases_recursive(tree->root, map);
    }

    delete_crevasse(tree->root);
    delete_invalid_nodes_from_tree(tree->root, map.x_max, map.y_max);

    //print_tree(tree->root, 0);


    clock_t end_build = clock();
    printf("Temps de construction de l'arbre : %f secondes\n", (double)(end_build - start_build) / CLOCKS_PER_SEC);
}


void print_tree(t_n_node * node, int depth) {
    if (node == NULL) {
        return;
    }

    for (int i = 0; i < depth; i++) {
        printf("     ");
    }

    printf("|----(mov=%s, x=%d, y=%d, ori=%d, nbsons=%d, cost=%d)\n", getMoveAsString(node->mouv), node->loc.pos.x, node->loc.pos.y, node->loc.ori, node->nbre_sons, node->cost);

    for (int i = 0; i < node->nbre_sons; i++) {
        print_tree(node->tab_sons[i], depth + 1);
    }
}

void delete_invalid_nodes_from_tree(t_n_node * node, int x, int y) {
    if (node == NULL) {
        return;
    }

    if (isValidLocalisation(node->loc.pos, x, y) == 0) {
        node->nbre_sons = 0;
        node->cost = 10000;
        liberer_arbre(node);
    }

    for (int i = 0; i<node->nbre_sons; i++) {
        delete_invalid_nodes_from_tree(node->tab_sons[i], x, y);
    }
}

void delete_crevasse(t_n_node * node) {
    if (node == NULL) {
        return;
    }

    if (node->cost > 9999) {
        node->nbre_sons = 0;
        liberer_arbre(*node->tab_sons);
    }
    for (int i = 0; i<node->nbre_sons; i++) {
        delete_crevasse(node->tab_sons[i]);
    }
}

void correct_erg_cases_recursive(t_n_node * node, t_map map) {
    if (node == NULL) {
        return;
    }

    if(node->tab_sons[0] == NULL) {
        return;
    }

    for(int i = 0; i < node->nbre_sons; i++) {
        if(node->tab_sons[i]->mouv == F_10) {
            node->tab_sons[i]->loc = node->loc;
        }
        if(node->tab_sons[i]->mouv == B_10){
            node->tab_sons[i]->loc = node->loc;
        }
        if(node->tab_sons[i]->mouv == F_20) {
            node->tab_sons[i]->loc = move(node->loc, F_10);

        }
        if(node->tab_sons[i]->mouv == F_30) {
            node->tab_sons[i]->loc = move(node->loc, F_20);
        }

        if(node->tab_sons[i]->mouv == T_LEFT) {
            node->tab_sons[i]->loc = move(node->loc, T_LEFT );
        }
        if(node->tab_sons[i]->mouv == T_RIGHT){
            node->tab_sons[i]->loc = move(node->loc, T_RIGHT );
        }
        if(node->tab_sons[i]->mouv == U_TURN){
            node->tab_sons[i]->loc = move(node->loc, U_TURN);
        }

        //mettre à jour le cout
        if(isValidLocalisation(node->tab_sons[i]->loc.pos, map.x_max, map.y_max) == 1) {
            node->tab_sons[i]->cost = map.costs[node->tab_sons[i]->loc.pos.y][node->tab_sons[i]->loc.pos.x];
        }
    }


    for (int i = 0; i<node->nbre_sons; i++) {
        correct_erg_cases_recursive(node->tab_sons[i], map);
    }

}

void liberer_arbre(t_n_node * node) {
    if (node == NULL) {
        return;
    }

    for (int i = 0; i < node->nbre_sons; i++) {
        liberer_arbre(node->tab_sons[i]);
    }

    free(node->tab_sons);
    free(node);
}

void findMinCostLeafWithStack(t_n_node * root, t_stack* currentPath, t_stack* bestPath, int* minCost, int A) {

    if (root == NULL) {
        return;
    }

    push(currentPath, root->mouv);

    if (root->nbre_sons == A) {
        if (root->cost < *minCost) {
            *minCost = root->cost;
            bestPath->nbElts = currentPath->nbElts;
            for (int i = 0; i < currentPath->nbElts; i++) {
                bestPath->values[i] = currentPath->values[i];
            }
        }
    } else {
        for (int i = 0; i < root->nbre_sons; i++) {
            findMinCostLeafWithStack(root->tab_sons[i], currentPath, bestPath, minCost, A);
        }
    }

    pop(currentPath);

}

t_stack getLeafWithMinCost(t_n_node* root, int A) {
    clock_t start_build = clock();
    if (root == NULL) {
        printf("L'arbre est vide.\n");
        t_stack currentPath = createStack(0);
        return currentPath;
    }

    t_stack currentPath = createStack(100);
    t_stack bestPath = createStack(100);

    int minCost = INT_MAX;

    findMinCostLeafWithStack(root, &currentPath, &bestPath, &minCost, A);

    printf("Coût minimal : %d\n", minCost);
    printf("Chemin vers la feuille avec le coût minimal : ");
    for (int i = 0; i < bestPath.nbElts; i++) {
        printf("%s ", getMoveAsString(bestPath.values[i]) );
    }
    printf("\n");

    free(currentPath.values);
    clock_t end_build = clock();
    printf("Temps de calcul du chemin : %f secondes\n", (double)(end_build - start_build) / CLOCKS_PER_SEC);
    return bestPath;
}

t_localisation phase(t_map map, int x, int y, t_orientation ori, int N, int A) {
    t_list liste = create_list();
    t_move * tab_aleatoire;
    tab_aleatoire = getRandomMoves(N);

    for(int i = 0; i < N ; i++) {
        insert_head_maillon(&liste, tab_aleatoire[i]);
    }

    //gerer les sols reg martien
    if(map.soils[y][x] == 3) {
        printf("sol reg");
        A = 5;
    }

    afficher_liste(liste);

    t_localisation point;
    point = loc_init(x,y,ori);
    t_n_tree tree;
    tree = initTree();
    makeTree(liste, &tree, map, point, N, A);

    t_stack bestPath;
    t_stack tempStack;

    bestPath = getLeafWithMinCost(tree.root, A);
    tempStack = createStack(N);

    t_move temp;

    point = move(point, U_TURN);

    while(bestPath.nbElts != 0) {
        temp = pop(&bestPath);
        push(&tempStack, temp);
    }

    if(map.soils[y][x] == 2) {
        while(tempStack.nbElts != 0) {
            temp = pop(&tempStack);
            //gerer les cases erg martien
            switch (temp) {
                case F_10  :
                    break;
                case B_10 :
                    break;
                case F_20 :
                    point = move(point, F_10);;
                break;
                case F_30 :
                    point = move(point, F_20);;
                break;
                default:
                    point = move(point, temp);
                break;
            }
        }
    }

    while(tempStack.nbElts != 0) {
        temp = pop(&tempStack);
        point = move(point, temp);
    }
    free(bestPath.values);
    free(tempStack.values);

    return point;
}


void cheminer_vers_la_base(t_map map, int x, int y, t_orientation ori, int N, int A) {
    clock_t start_build = clock();
    clock_t start = clock();
    t_localisation loc;
    printf("\n%d %d %d\n", x, y, ori);
    loc = phase(map, x, y, ori, N, A);
    printf("\n%d %d %d\n", loc.pos.x, loc.pos.y, loc.ori);
    while(map.costs[loc.pos.y][loc.pos.x] != 0){
        loc = phase(map, loc.pos.x, loc.pos.y, loc.ori, N, A);
        printf("\n%d %d %d\n", loc.pos.x, loc.pos.y, loc.ori);
    }
    clock_t end = clock();
    double elapsed_time = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Temps pour ramener MARC à la base est de : %f secondes\n", elapsed_time);
    clock_t end_build = clock();
    printf("Temps de guidage de MARC vers la base: %f secondes\n", (double)(end_build - start_build) / CLOCKS_PER_SEC);
}



