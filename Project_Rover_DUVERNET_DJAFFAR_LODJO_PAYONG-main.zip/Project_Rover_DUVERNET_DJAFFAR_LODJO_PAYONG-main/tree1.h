//
// Created by LODJO Oluwa-fèmi on 14/11/2024.
//

#ifndef TREE1_H
#define TREE1_H

#include "loc.h"
#include "moves.h"
#include "map.h"
#include "liste.h"
#include "stack.h"

struct n_node {
    int cost;
    t_localisation loc;
    struct n_node ** tab_sons;
    int nbre_sons;
    t_move mouv;
};
typedef struct n_node t_n_node;

struct n_tree{
    t_n_node * root;
};
typedef struct n_tree t_n_tree;

t_n_tree initTree();

t_n_node *createNode(t_localisation loca, int nbr_sons, t_map map, t_move mouve);

void makeNode(t_n_node *node, t_list liste, t_map map, int N, int A);

void recusive_function(t_maillon liste, t_n_node *node, t_map map, int N, int A);

void makeTree(t_list liste, t_n_tree *tree, t_map map, t_localisation depart_point, int N, int A);

void print_tree(t_n_node *node, int depth);

void delete_invalid_nodes_from_tree(t_n_node *node, int x, int y);

void delete_crevasse(t_n_node *node);

void correct_erg_cases_recursive(t_n_node *node, t_map map);

void liberer_arbre(t_n_node *node);

t_stack getLeafWithMinCost(t_n_node *root, int A);

t_localisation phase(t_map map, int x, int y, t_orientation ori, int N, int A);

void cheminer_vers_la_base(t_map map, int x, int y, t_orientation ori, int N, int A);


#endif //TREE1_H
